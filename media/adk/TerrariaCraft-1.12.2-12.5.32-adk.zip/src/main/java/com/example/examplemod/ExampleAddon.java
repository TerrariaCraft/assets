package com.example.examplemod;

import com.example.examplemod.init.BlocksEM;
import com.example.examplemod.init.ItemsEM;
import com.zeitheron.hammercore.internal.SimpleRegistration;
import net.minecraft.init.Blocks;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLConstructionEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.zeith.terraria.api.crafting.events.RegisterCraftingEvent;
import org.zeith.terraria.api.mod.ITerrariaMod;
import org.zeith.terraria.utils.forge.DeferredRegistries;

@Mod(
		modid = ExampleAddon.MODID,
		name = ExampleAddon.NAME,
		version = ExampleAddon.VERSION,
		dependencies = "required-after:terraria"
)
public class ExampleAddon
		implements ITerrariaMod
{
	public static final String MODID = "examplemod";
	public static final String NAME = "Example Mod";
	public static final String VERSION = "1.0";

	public final DeferredRegistries registries = new DeferredRegistries(this);

	private static Logger logger = LogManager.getLogger(MODID);

	public ExampleAddon()
	{
		// Used to add custom recipes
		MinecraftForge.EVENT_BUS.register(this);
	}

	@EventHandler
	public void construction(FMLConstructionEvent event)
	{
		// This is very recommended for common addon setup.
		ITerrariaMod.super.constructionEvent(event);
	}

	@EventHandler
	public void preInit(FMLPreInitializationEvent event)
	{
		logger = event.getModLog();

		// Registers all items
		SimpleRegistration.registerFieldItemsFrom(ItemsEM.class, MODID, null);

		// Registers all blocks
		SimpleRegistration.registerFieldBlocksFrom(BlocksEM.class, MODID, null);
	}

	@Override
	public DeferredRegistries getRegistries()
	{
		return registries;
	}

	@SubscribeEvent
	public void addRecipes(RegisterCraftingEvent e)
	{
		e.addHeavyWorkBenchRecipe(BlocksEM.EXAMPLE_BAR.stack(), BlocksEM.EXAMPLE_BLOCK.stack(4));
	}
}
