package com.example.examplemod.init;

import com.example.examplemod.common.content.items.ExampleItem;
import com.example.examplemod.common.content.items.ExampleSword;

public class ItemsEM
{
	public static final ExampleItem EXAMPLE_ITEM = new ExampleItem("example_material");

	public static final ExampleSword EXAMPLE_SWORD = new ExampleSword(14, "example");
}